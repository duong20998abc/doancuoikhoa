package application.constant;

public class Constant {
    public final static String PREFIX_LINK_UPLOAD = "/link/";
    public final static int DEFAULT_PAGE_SIZE = 10;
}
